package com.example.goracing

interface GameTask
{
    fun closeGame(score:Int)
}